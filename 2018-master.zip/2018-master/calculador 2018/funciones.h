#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

float suma(float , float);
float resta(float , float );
float dividir(float , float );
float multi(float , float);
float factorial(float);

#endif // FUNCIONES_H_INCLUDED
