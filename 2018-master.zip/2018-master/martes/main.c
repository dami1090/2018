#include <stdio.h>
#include <stdlib.h>

int main()
{

   printf("\n 1=correcto\n 0=incorrecto\n respuesta --> %d ",verifica());


}
